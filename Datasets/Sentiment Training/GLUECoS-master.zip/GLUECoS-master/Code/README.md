Baseline evaluation code
