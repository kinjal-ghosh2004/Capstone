Pre-process each dataset
